
drop table member;

create table member (
id varchar2(15) primary key,
pass varchar2(10) not null,
name varchar2(15) not null,
age number(3) not null,
gender  varchar2(5) not null,
email  varchar2(30) not null
);

select * from member;

